﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Winger.Network.Encryption.RSA
{
    public class PrivateKey
    {
        private long p = 0;
        private long q = 0;

        public PrivateKey(long p, long q)
        {

        }

        public PrivateKey()
        {

        }
    }
}
