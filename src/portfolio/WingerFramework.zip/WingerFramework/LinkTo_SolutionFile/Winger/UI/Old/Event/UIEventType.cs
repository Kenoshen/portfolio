﻿
namespace Winger.UI.Event
{
    public enum UIEventType
    {
        HOVER_START,
        HOVER_END,
        SELECT_START,
        SELECT_END,
        CUSTOM,
    }
}
