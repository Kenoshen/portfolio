﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Winger.UI.HTML.Elements
{
    public class HTMLElementInput : HTMLElement
    {
        public HTMLElementInput(HTMLTag tag)
        {
            Tag = tag;
        }
    }
}
