﻿
namespace Winger.Input.Event
{
    public enum InputEvent
    {
        JUMP,
        ATTACKLIGHT,
        ATTACKHEAVY,
        BLOCK,
        MODMAGIC,
        MODRANGE,
        MOVE,
        PAUSE,
        MAP,
    }
}
