﻿
namespace Winger.Input.Event
{
    public enum InputEventType
    {
        DOWN,
        UP,
        CHANGE,
    }
}
